const AnalyticsPage = () => {
    return ( 
        <div>
            <h1>Analytics Page</h1>
        </div>

     );
}
 
export default AnalyticsPage;